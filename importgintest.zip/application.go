// main.go

package main

import (
	"github.com/gin-gonic/gin"
)

// Create the router
var router *gin.Engine

/*
Configures the router to load HTML templates
Sets the lower memory limit
Initializes the routes for the router
Hard codes the port for hosting
*/
func main() {
	gin.SetMode(gin.ReleaseMode)
	router = gin.Default()
	router.Static("/static", "./static")
	router.LoadHTMLGlob("templates/*")
	router.MaxMultipartMemory = 8 << 20
	//initializeRoutes()
	router.Run(":80")
}
